


import org.gummymodules.core.types.EventType;
import java.util.HashMap;
import java.util.ArrayList;

public class GetInfo extends EventTypeBase
{
	
	public GetInfo()
	{
		super();
	}
	
}

