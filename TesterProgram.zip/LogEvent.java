

import org.gummymodules.core.types.EventType;
import java.util.HashMap;
import java.util.ArrayList;

public class LogEvent extends EventTypeBase
{
	
	public LogEvent()
	{
		super();
	}
	
}

