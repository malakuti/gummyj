

import java.util.HashMap;

import org.gummymodules.core.helpers.GummyException;
import org.gummymodules.core.helpers.PublishingMode;
import org.gummymodules.core.metamodel.GummyModule;
import org.gummymodules.core.runtime.EventReceiver;
import org.gummymodules.core.runtime.GummyJ;
import org.gummymodules.core.runtime.RuntimeManager;

import TMS.CarCoordinate;
import TMS.SegmentCoordinate;

public class Tester {

	public static void main(String[] args){
		try {

	
			GummyJ.introduce(TrafficCongestion.class,  new SegmentCoordinate(10));
			GummyJ.introduce(TrafficCongestion.class,  new SegmentCoordinate(20));

			CarEvent e = new CarEvent();
			e.setPublisher(new Long(1));
			e.setCoordinate(new CarCoordinate());
			e.setTime(new Long(10));
		
			GummyJ.publish(e, PublishingMode.SYNCHRONOUS);

			GummyJ.publish(e, PublishingMode.SYNCHRONOUS);

			LogEvent ee = new LogEvent();
			ee.setPublisher(new Long(1));
			GummyJ.publish(ee, PublishingMode.ASYNCHRONOUS);


			HashMap<String, GummyModule> modules =  GummyJ.retrieveall();
			for (String key: modules.keySet())
			{
				GetInfo gi = new GetInfo();
				gi.setPublisher(new Long(1));
				gi.addAttribute("elapsedTime", new Long(0));
				gi.addAttribute("target", key);
				GummyJ.publish(gi, PublishingMode.SYNCHRONOUS);
				if (gi.getAttribute("elapsedTime") == null) {
					System.out.println("No active GM");
				}
				else{
					System.out.println(((Long)gi.getAttribute("elapsedTime")).longValue());
				}
			}
			
		} catch (GummyException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}

