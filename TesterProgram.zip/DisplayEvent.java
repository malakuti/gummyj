

import org.gummymodules.core.types.EventType;
import java.util.HashMap;
import java.util.ArrayList;

public class DisplayEvent extends EventTypeBase
{
	
	public DisplayEvent()
	{
		super();
	}
	
}

