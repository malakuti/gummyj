

import org.gummymodules.core.types.EventType;
import org.gummymodules.core.types.Construct;
import org.gummymodules.core.types.Destruct;
import org.gummymodules.core.types.AppearanceTerminated;
import org.gummymodules.core.types.DisappearanceTerminated;
import org.gummymodules.core.metamodel.GummyModule;
import org.gummymodules.core.metamodel.AppearanceGummyModule;
import org.gummymodules.core.metamodel.DisappearanceGummyModule;
import org.gummymodules.core.metamodel.OutterGummyModule;
import org.gummymodules.core.metamodel.AtomicProgram;
import org.gummymodules.core.metamodel.BindingInfo;
import org.gummymodules.core.helpers.GummyException;
import org.gummymodules.core.helpers.Instantiator;
import java.util.HashMap;
import java.util.ArrayList;
 import TMS.*;
 
public class TrafficCongestion extends OutterGummyModule
{
 
  public class GummyModule_TrafficCongestion_EventMethod_appearance extends AppearanceGummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_appearance(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this.enclosing, GummyModule_TrafficCongestion_EventMethod_appearance_selector.class.getName(), "selector"));
      }
 
      // provided
      {
        this.addProvidedInterface(Instantiator.instantiateProvidedNested(TrafficCongestion.class, this.enclosing, Construct.class.getName(), "Construct"));
        this.addProvidedInterface(Instantiator.instantiateProvidedNested(TrafficCongestion.class, this.enclosing, AppearanceTerminated.class.getName(), "terminated"));
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_appearance_implementation(this, "baseprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("selector.result", "baseprog"));
        this.binder.getBindings().add(new BindingInfo("baseprog", "Construct"));
        this.binder.getBindings().add(new BindingInfo("baseprog", "terminated"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_appearance_selector extends GummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_appearance_selector(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequired(EventType.class.getName(), "input"));
      }
 
      // provided
      {
        this.addProvidedInterface(Instantiator.instantiateProvided(EventType.class.getName(), "result"));
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_appearance_selector_implementation(this, "selectorprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("input", "selectorprog"));
        this.binder.getBindings().add(new BindingInfo("selectorprog", "result"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_appearance_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_appearance_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      initialize();
      {
        System.out.println("### appearance");
        Long avg = TMSHelper.computeAverageWaitingTime(initializer_a_cars, initializer_a_times, input);
        if ((avg >= W))
        {
          this.publish(new Construct());
          w_time = avg;
          cars.putAll(initializer_a_cars);
        }
      }
      if (((GummyModule)(((GummyModule)(this.enclosing)).getEnclosing())).constructing)
      {
        this.publish(new AppearanceTerminated());
      }
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_appearance_selector_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_appearance_selector_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      if ((((false || (input instanceof CarEvent))) && TMSHelper.inSegment(((TMS.CarCoordinate)(input.getAttribute("coordinate"))), parameter_s_coordinate)))
      {
        this.publish(input);
      }
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_disappearance extends DisappearanceGummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_disappearance(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this.enclosing, GummyModule_TrafficCongestion_EventMethod_disappearance_selector.class.getName(), "selector"));
      }
 
      // provided
      {
        this.addProvidedInterface(Instantiator.instantiateProvidedNested(TrafficCongestion.class, this.enclosing, Destruct.class.getName(), "Destruct"));
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_disappearance_implementation(this, "baseprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("selector.result", "baseprog"));
        this.binder.getBindings().add(new BindingInfo("baseprog", "Destruct"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_disappearance_selector extends GummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_disappearance_selector(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequired(EventType.class.getName(), "input"));
      }
 
      // provided
      {
        this.addProvidedInterface(Instantiator.instantiateProvided(EventType.class.getName(), "result"));
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_disappearance_selector_implementation(this, "selectorprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("input", "selectorprog"));
        this.binder.getBindings().add(new BindingInfo("selectorprog", "result"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_disappearance_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_disappearance_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      {
        System.out.println("### disappearance");
        Long avg = TMS.TMSHelper.computeAverageWaitingTime(cars, times, input);
        if ((avg < W))
        {
          this.publish(new Destruct());
        }
      }
      if (((GummyModule)(((GummyModule)(this.enclosing)).getEnclosing())).destructing)
      {
        this.publish(new DisappearanceTerminated());
      }
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_disappearance_selector_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_disappearance_selector_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      if ((((false || (input instanceof CarEvent))) && TMS.TMSHelper.inSegment(((TMS.CarCoordinate)(input.getAttribute("coordinate"))), parameter_s_coordinate)))
      {
        this.publish(input);
      }
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_update extends GummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_update(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this.enclosing, GummyModule_TrafficCongestion_EventMethod_update_selector.class.getName(), "selector"));
      }
 
      // provided
      {
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_update_implementation(this, "baseprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("selector.result", "baseprog"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_update_selector extends GummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_update_selector(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequired(EventType.class.getName(), "input"));
      }
 
      // provided
      {
        this.addProvidedInterface(Instantiator.instantiateProvided(EventType.class.getName(), "result"));
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_update_selector_implementation(this, "selectorprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("input", "selectorprog"));
        this.binder.getBindings().add(new BindingInfo("selectorprog", "result"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_update_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_update_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      System.out.println("### update");
      w_time = TMS.TMSHelper.computeAverageWaitingTime(cars, times, input);
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_update_selector_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_update_selector_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      if ((((false || (input instanceof CarEvent))) && TMS.TMSHelper.inSegment(((TMS.CarCoordinate)(input.getAttribute("coordinate"))), parameter_s_coordinate)))
      {
        this.publish(input);
      }
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_getWaitingTime extends GummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_getWaitingTime(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this.enclosing, GummyModule_TrafficCongestion_EventMethod_getWaitingTime_selector.class.getName(), "selector"));
      }
 
      // provided
      {
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_getWaitingTime_implementation(this, "baseprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("selector.result", "baseprog"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_getWaitingTime_selector extends GummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_getWaitingTime_selector(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequired(EventType.class.getName(), "input"));
      }
 
      // provided
      {
        this.addProvidedInterface(Instantiator.instantiateProvided(EventType.class.getName(), "result"));
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_getWaitingTime_selector_implementation(this, "selectorprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("input", "selectorprog"));
        this.binder.getBindings().add(new BindingInfo("selectorprog", "result"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_getWaitingTime_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_getWaitingTime_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      System.out.println("### getWaitingTime");
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_getWaitingTime_selector_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_getWaitingTime_selector_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      if ((((false || (input instanceof GetInfo))) && TMS.TMSHelper.inSegment(((TMS.CarCoordinate)(input.getAttribute("coordinate"))), parameter_s_coordinate)))
      {
        this.publish(input);
      }
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_log extends GummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_log(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this.enclosing, GummyModule_TrafficCongestion_EventMethod_log_selector.class.getName(), "selector"));
      }
 
      // provided
      {
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_log_implementation(this, "baseprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("selector.result", "baseprog"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_log_selector extends GummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_log_selector(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequired(EventType.class.getName(), "input"));
      }
 
      // provided
      {
        this.addProvidedInterface(Instantiator.instantiateProvided(EventType.class.getName(), "result"));
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_log_selector_implementation(this, "selectorprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("input", "selectorprog"));
        this.binder.getBindings().add(new BindingInfo("selectorprog", "result"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_log_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_log_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      System.out.println("### log");
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_log_selector_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_log_selector_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      if (((false || (input instanceof LogEvent))))
      {
        this.publish(input);
      }
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_display extends GummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_display(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this.enclosing, GummyModule_TrafficCongestion_EventMethod_display_selector.class.getName(), "selector"));
      }
 
      // provided
      {
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_display_implementation(this, "baseprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("selector.result", "baseprog"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_display_selector extends GummyModule
  {
 
    public GummyModule_TrafficCongestion_EventMethod_display_selector(GummyModule enclosing, String name) throws GummyException
    {
      super(name, name);
      this.enclosing = enclosing;
 
      // required
      {
        this.addRequiredInterface(Instantiator.instantiateRequired(EventType.class.getName(), "input"));
      }
 
      // provided
      {
        this.addProvidedInterface(Instantiator.instantiateProvided(EventType.class.getName(), "result"));
      }
 
      // program
      {
        this.addPrograms(((TrafficCongestion)(this.enclosing)).new GummyModule_TrafficCongestion_EventMethod_display_selector_implementation(this, "selectorprog"));
      }
 
      this.computeMetaData();
 
      // bindings
      {
        this.binder.getBindings().add(new BindingInfo("input", "selectorprog"));
        this.binder.getBindings().add(new BindingInfo("selectorprog", "result"));
      }
 
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_display_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_display_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      System.out.println("### display");
    }
 
  }
 
 
  public class GummyModule_TrafficCongestion_EventMethod_display_selector_implementation extends AtomicProgram
  {
 
    public GummyModule_TrafficCongestion_EventMethod_display_selector_implementation(GummyModule enclosing, String name) throws GummyException
    {
      super(name);
      this.enclosing = enclosing;
    }
 
    public void execute(EventType input) throws GummyException
    {
      if (((false || (input instanceof DisplayEvent))))
      {
        this.publish(input);
      }
    }
 
  }
 
  private boolean appearance_initialized = false;
  private TMS.SegmentCoordinate parameter_s_coordinate;
  private static Long T = new Long(10);
  private static Long W = new Long(30);
  private Long w_time;
  private HashMap<Long,TMS.CarInfo> cars = new HashMap<Long,TMS.CarInfo>();
  private ArrayList<Long> times = new ArrayList<Long>();
  private HashMap<Long,TMS.CarInfo> initializer_a_cars;
  private ArrayList<Long> initializer_a_times;
 
  public TrafficCongestion(String name, TMS.SegmentCoordinate s_coordinate) throws GummyException
  {
    super(name, name);
    this.parameter_s_coordinate = s_coordinate;
 
    // required
    {
      this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this, GummyModule_TrafficCongestion_EventMethod_appearance.class.getName(), "GummyModule_TrafficCongestion_EventMethod_appearance"));
      this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this, GummyModule_TrafficCongestion_EventMethod_disappearance.class.getName(), "GummyModule_TrafficCongestion_EventMethod_disappearance"));
      this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this, GummyModule_TrafficCongestion_EventMethod_update.class.getName(), "GummyModule_TrafficCongestion_EventMethod_update"));
      this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this, GummyModule_TrafficCongestion_EventMethod_getWaitingTime.class.getName(), "GummyModule_TrafficCongestion_EventMethod_getWaitingTime"));
      this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this, GummyModule_TrafficCongestion_EventMethod_log.class.getName(), "GummyModule_TrafficCongestion_EventMethod_log"));
      this.addRequiredInterface(Instantiator.instantiateRequiredNested(TrafficCongestion.class, this, GummyModule_TrafficCongestion_EventMethod_display.class.getName(), "GummyModule_TrafficCongestion_EventMethod_display"));
    }
 
    // provided
    {
      this.addProvidedInterface(Instantiator.instantiateProvidedNested(TrafficCongestion.class, this, Construct.class.getName(), "Construct"));
      this.addProvidedInterface(Instantiator.instantiateProvidedNested(TrafficCongestion.class, this, Destruct.class.getName(), "Destruct"));
    }
 
    this.computeMetaData();
 
    // bindings
    {
      this.binder.getBindings().add(new BindingInfo("GummyModule_TrafficCongestion_EventMethod_appearance.Construct", "Construct"));
      this.binder.getBindings().add(new BindingInfo("GummyModule_TrafficCongestion_EventMethod_disappearance.Destruct", "Destruct"));
    }
 
    // miscelleneous
    {
      /*
      this.setAppearance(new GummyModule_TrafficCongestion_EventMethod_appearance());
       */
      /*
      this.setDisappearance(new GummyModule_TrafficCongestion_EventMethod_disappearance());
       */
    }
 
  }
 
  private Long get_w_time()
  {
    return this.w_time;
  }
 
  private void set_w_time(Long w_time)
  {
    this.w_time = w_time;
  }
 
  private HashMap<Long,TMS.CarInfo> get_cars()
  {
    return this.cars;
  }
 
  private void set_cars(HashMap<Long,TMS.CarInfo> cars)
  {
    this.cars = cars;
  }
 
  private ArrayList<Long> get_times()
  {
    return this.times;
  }
 
  private void set_times(ArrayList<Long> times)
  {
    this.times = times;
  }
 
  private void initialize()
  {
    if ((! this.appearance_initialized))
    {
      {
        this.initializer_a_cars = new HashMap<Long,TMS.CarInfo>();
        this.initializer_a_times = new ArrayList<Long>();
      }
      this.appearance_initialized = true;
    }
  }
 
}


