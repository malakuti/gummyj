

import org.gummymodules.core.types.EventType;

import TMS.CarCoordinate; //Somayeh

public class CarEvent extends EventType
{
	
	public CarEvent()
	{
		//----- Somayeh ------
		super("CarEvent");
		this.addAttribute("coordinate", null);
		this.addAttribute("time", null);
	}
	
	//------------ Somayeh -----------------
	public CarCoordinate getCoordinate() {
		return coordinate;
	}
	public void setCoordinate(CarCoordinate coordinate) {
		this.coordinate = coordinate;
		this.addAttribute("coordinate", time);
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
		this.addAttribute("time", time);
	}

	private CarCoordinate coordinate; 
	private Long time; 
	
	
	
}

