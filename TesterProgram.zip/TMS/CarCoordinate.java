package TMS;

public class CarCoordinate {

}
