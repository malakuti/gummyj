package TMS;

public class SegmentCoordinate {

	public int c;
	public SegmentCoordinate (int val){
		c = val;
	}
}
