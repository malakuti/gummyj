package TMS;

import org.gummymodules.core.types.EventType;

public class CarInfo {

	public Long time;
	public Long id;
	
	public CarInfo (EventType event){
		time = (Long) event.getAttribute("time");
		id = (Long) event.getAttribute("publisher");
	}
}
