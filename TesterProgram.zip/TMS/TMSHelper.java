package TMS;

import java.util.ArrayList;
import java.util.HashMap;

import org.gummymodules.core.types.EventType;

public class TMSHelper {
	static Long starttime, endtime = new Long(0);
	static int c = 0;
	public static Long computeTravelTime(CarInfo car,EventType input){
		return (car.time - (long )input.getAttribute("time"));
	}
	public static Long computeElapsedTime() {
		
//		if (c == 0) {c = 1; starttime= System.currentTimeMillis();}
//		else
//		endtime = System.currentTimeMillis();
//		return endtime -starttime;
		
		return new Long(15);
	}
	public static Long  computeAverageTime(ArrayList<Long> times){
		return (long) 50;
		
	}
	public static Boolean checkCoordinate(CarCoordinate cc, SegmentCoordinate sc) {
		// TODO Auto-generated method stub
		return true;
	}
	public static Boolean coordinateMatches(SegmentCoordinate sc1,
			SegmentCoordinate sc2) {
		// TODO Auto-generated method stub
		return true;
	}
	
	public static Long computeAverageWaitingTime(HashMap<Long, TMS.CarInfo> cars, ArrayList<Long> times, EventType input_) {
	    if (cars.get(input_.getAttribute("publisher")) == null) {
	      /*
	      cars.put((Long)input_.getAttribute("publisher"), new TMS.CarInfo(input_));
	       */
	    }
	    else {
	      times.add(TMS.TMSHelper.computeTravelTime(cars.get(input_.getAttribute("publisher")), input_));
	      cars.remove(input_.getAttribute("publisher"));
	    }
	    if (TMS.TMSHelper.computeElapsedTime() > 10)
	      return TMS.TMSHelper.computeAverageTime(times);
	    else
	      return (new Long(-1));
	  }
	  
	
	public static Boolean inSegment (TMS.CarCoordinate cc, TMS.SegmentCoordinate sc) {
	    return TMS.TMSHelper.checkCoordinate(cc, sc);
	  }
	  
	 public static Boolean matches(TMS.SegmentCoordinate sc1,TMS.SegmentCoordinate sc2) {
	    return TMS.TMSHelper.coordinateMatches(sc1, sc2);
	  }
	  
	  /*
	  selector := (input.type == CarEvent.class && inSegment(input.coordinate, s_coordinate));
	   */
	  
}
