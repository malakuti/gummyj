package TMS;

import org.gummymodules.core.types.EventType;

public class Car {

	public Car (EventType ev){
		
	}
}
