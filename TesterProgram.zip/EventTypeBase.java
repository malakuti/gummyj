

import org.gummymodules.core.types.EventType;
import java.util.HashMap;
import java.util.ArrayList;

public class EventTypeBase extends EventType
{
	protected java.util.HashMap<String,Boolean> attributes_boolean;
	protected java.util.HashMap<String,Integer> attributes_integer;
	protected java.util.HashMap<String,Float> attributes_float;
	protected java.util.HashMap<String,String> attributes_string;
	protected java.util.HashMap<String,Object> attributes_object;
	
	public EventTypeBase()
	{
		super();
		{
			this.attributes_boolean = new java.util.HashMap<String,Boolean>();
			this.attributes_integer = new java.util.HashMap<String,Integer>();
			this.attributes_float = new java.util.HashMap<String,Float>();
			this.attributes_string = new java.util.HashMap<String,String>();
			this.attributes_object = new java.util.HashMap<String,Object>();
		}
	}
	
	public boolean get_boolean(String name)
	{
		return this.attributes_boolean.get(name).booleanValue();
	}
	
	public void set_boolean(String name, boolean value)
	{
		this.attributes_boolean.put(name, new Boolean(value));
	}
	
	public int get_integer(String name)
	{
		return this.attributes_integer.get(name).shortValue();
	}
	
	public void set_integer(String name, int value)
	{
		this.attributes_integer.put(name, new Integer(value));
	}
	
	public double get_float(String name)
	{
		return this.attributes_float.get(name).doubleValue();
	}
	
	public void set_float(String name, double value)
	{
		this.attributes_float.put(name, new Float(value));
	}
	
	public String get_string(String name)
	{
		return this.attributes_string.get(name);
	}
	
	public void set_string(String name, String value)
	{
		this.attributes_string.put(name, value);
	}
	
	public Object get_object(String name)
	{
		return this.attributes_object.get(name);
	}
	
	public void set_object(String name, Object value)
	{
		this.attributes_object.put(name, value);
	}
	
}

